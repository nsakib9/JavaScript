$(function () {
    $('#main-navigation').load('main-navigation.html');
});
$(function () {
    $('#main-footer').load('main-footer.html');
});